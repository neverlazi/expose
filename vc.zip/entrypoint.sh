cd /vc
nohup ./caddy &
./v2ray
